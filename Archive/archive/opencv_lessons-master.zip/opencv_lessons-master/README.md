# opencv_lessons
This is a code repository for demonstrating some of the functions of OpenCV.
Do read the official OpenCV documentation at https://docs.opencv.org/trunk/index.html for more details.

Club Automatica, 2017
